import { Component } from '@angular/core';

@Component({
  selector: 'app-calendar',
  imports: [],
  template: `
    <p>
      calendar works!
    </p>
  `,
  styles: ``
})
export class CalendarComponent {

}
