import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { Task } from '../../models/task.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  standalone: false
})
export class DashboardComponent implements OnInit {
  total = 0;
  completed = 0;
  pending = 0;

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    const token = localStorage.getItem('jwtToken') || '';
    this.taskService.getAllTasksWithToken(token).subscribe((tasks: Task[]) => {
      this.total = tasks.length;
      this.completed = tasks.filter(task => task.status === 'completed').length;
      this.pending = tasks.filter(task => task.status !== 'completed').length;
    });
  }
}
