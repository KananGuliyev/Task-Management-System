import { Component } from '@angular/core';

@Component({
  selector: 'app-messages',
  imports: [],
  template: `
    <p>
      messages works!
    </p>
  `,
  styles: ``
})
export class MessagesComponent {

}
