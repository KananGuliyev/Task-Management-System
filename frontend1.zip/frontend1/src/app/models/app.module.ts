import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [/* komponentlər */],
  imports: [
    BrowserAnimationsModule,
    // digər modullar
  ],
  bootstrap: [/* AppComponent və s. */]
})
export class AppModule {}